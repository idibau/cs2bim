# cs2bim-tin2ifc

## Build
```
pip install -q build
python -m build
```

The build files are saved in the "dist/" folder.


## Code structure

This library consists of three different main packages, "build", "enum" and "model".

### build

Builds an Ifc file using the ifcopenshell library based on a model object.

### enum

Contains all enums definded in this library.

### model

Captures all data that is needed to build an Ifc.

## Usage

See "examples/main.py"