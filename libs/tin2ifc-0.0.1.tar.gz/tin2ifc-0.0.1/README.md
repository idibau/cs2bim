# cs2bim-tin2ifc

This repository is responsible for creating ifc files with the special feature of also processing and mapping TIN data. TINs are a form of vector-based digital geographic data and are constructed by triangulating a set of vertices. The ifcs that are created, consist of a base, with meta information about the content of the file and feature classes, that represent a collection of geographic features with the same geometry type, the same attributes, and the same spatial reference.

## Build
```
pip install -q build
python -m build
```

The build files are saved in the "dist/" folder.


## Code structure

This library consists of three different main packages, "build", "enum" and "model".

### build

Builds an Ifc file using the ifcopenshell library based on a model object.

### enum

Contains all enums definded in this library.

### model

Captures all data that is needed to build an Ifc.

## Usage

See "examples/main.py"