# Cs2bim Tin2ifc

### Conventions

Type hints on functions: params, return type