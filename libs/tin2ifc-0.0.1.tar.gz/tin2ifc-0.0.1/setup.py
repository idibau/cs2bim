from setuptools import find_packages, setup

setup(
    name="tin2ifc",
    packages=find_packages(include=["tin2ifc", "tin2ifc.*"]),
    version="0.0.1",
    description="tin2ifc",
    author="FHNW",
    install_requires=[
        "ifcopenshell==0.7.0.240406",
        "numpy==1.26.4",
        "numpy-stl==3.1.1",
    ],
    tests_require=["pytest==4.4.1"],
    test_suite="test",
)
