from enum import Enum


class ColorDefionition(Enum):
    PARCEL = 0