from enum import Enum


class GeoReferencing(Enum):
    LO_GEO_REF_30 = 0
    LO_GEO_REF_40 = 1
    LO_GEO_REF_50 = 2
