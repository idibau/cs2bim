from enum import Enum


class GeometryRepresentaion(Enum):
    TESSELLATION = "Tessellation"
    BREP = "Brep"
