from dataclasses import dataclass, field

from tin2ifc.geo_referencing import GeoReferencing
from tin2ifc.geometry_representaion import GeometryRepresentaion
from tin2ifc.color_definitions import ColorDefionition


@dataclass
class IfcConfig:
    schema: str = "IFC4"
    author: str = "FHNW"
    version: str = "1.0"
    application_name: str = "cs2bim"
    project_name: str = "cs2bim"
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0)
    origin_shift: tuple[float, float, float] = (0.0, 0.0, 0.0)
    geo_referencing: GeoReferencing = GeoReferencing.LO_GEO_REF_30
    geometry_representation: GeometryRepresentaion = GeometryRepresentaion.TESSELLATION
    color_definitions: dict[ColorDefionition, tuple[float, float, float, float]] = (
        field(
            default_factory=lambda: {ColorDefionition.PARCEL: (0.31, 0.67, 0.04, 0.85)}
        )
    )

    def __str__(self):
        return f""
