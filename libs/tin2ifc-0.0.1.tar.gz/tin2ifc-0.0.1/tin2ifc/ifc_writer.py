import datetime
from ifcopenshell import file

from tin2ifc.ifc_utils import *
from tin2ifc.ifc_config import IfcConfig
from tin2ifc.geo_referencing import GeoReferencing
from tin2ifc.geometry_representaion import GeometryRepresentaion
from tin2ifc.color_definitions import ColorDefionition
from tin2ifc.triangulation import Triangulation

logger = logging.getLogger(__name__)

ZERO_LOCATION = (0.0, 0.0, 0.0)


class IfcWriter:

    def __init__(self, file_name: str, config: IfcConfig = IfcConfig()) -> None:
        logger.info(f"initialize new ifc writer for ifc '{file_name}'")
        self.file_name = file_name
        self.load_config(config)
        self.ifc_file = None
        self.parcels = []
        
    def load_config(self, config: IfcConfig):
        logger.info(f"load config")
        self.schema = config.schema
        self.author = config.author
        self.version = config.version
        self.application_name = config.application_name
        self.project_name = config.project_name
        self.origin = config.origin
        self.origin_shift = config.origin_shift
        self.geo_referencing = config.geo_referencing
        self.geometry_representation = config.geometry_representation
        self.color_definitions = config.color_definitions

    def add_parcel(self, triangulation: Triangulation):
        self.parcels.append(triangulation)

    def build(self):
        logger.info(f"build ifc")
        self.ifc_file = file(schema=self.schema)
        self.ifc_file.wrapped_data.header.file_name.name = self.file_name

        person = add_ifc_person(self.ifc_file, self.author)
        organization = add_ifc_organization(self.ifc_file, self.author)
        person_and_organization = add_ifc_person_and_organization(
            self.ifc_file, person, organization
        )
        application = add_ifc_application(
            self.ifc_file, organization, self.version, self.application_name
        )
        owner_history = add_ifc_owner_history(
            self.ifc_file,
            person_and_organization,
            application,
            int(datetime.datetime.now().timestamp()),
        )

        length_unit = add_ifc_si_unit(self.ifc_file, "LENGTHUNIT", "METRE")
        area_unit = add_ifc_si_unit(self.ifc_file, "AREAUNIT", "SQUARE_METRE")
        volume_unit = add_ifc_si_unit(self.ifc_file, "VOLUMEUNIT", "CUBIC_METRE")
        degree_unit = add_ifc_si_unit(self.ifc_file, "PLANEANGLEUNIT", "RADIAN")
        plane_angle_measure = add_ifc_plane_angle_measure(self.ifc_file)
        measure_with_unit = add_ifc_measure_with_unit(
            self.ifc_file, plane_angle_measure, degree_unit
        )
        dimensional_exponents = add_ifc_dimensional_exponents(self.ifc_file)
        conversion_based_unit = add_ifc_conversion_based_unit(
            self.ifc_file, dimensional_exponents, measure_with_unit
        )
        unit_assignment = add_ifc_unit_assignment(
            self.ifc_file, length_unit, area_unit, volume_unit, conversion_based_unit
        )

        if self.geo_referencing == GeoReferencing.LO_GEO_REF_40:
            context_location = add_ifc_cartesian_point(self.ifc_file, self.origin)
        else:
            context_location = add_ifc_cartesian_point(self.ifc_file, ZERO_LOCATION)
        axis_2_placement_3D = add_ifc_axis_2_placement_3D(
            self.ifc_file, context_location
        )
        representation_context = add_ifc_geometric_representation_context(
            self.ifc_file, axis_2_placement_3D
        )

        if self.geo_referencing == GeoReferencing.LO_GEO_REF_50:
            projected_crs = add_ifc_projected_crs(self.ifc_file, length_unit)
            add_ifc_map_conversion(
                self.ifc_file, representation_context, projected_crs, self.origin
            )

        project = add_ifc_project(
            self.ifc_file,
            self.project_name,
            owner_history,
            representation_context,
            unit_assignment,
        )

        if self.geo_referencing == GeoReferencing.LO_GEO_REF_30:
            site_location = add_ifc_cartesian_point(self.ifc_file, self.origin)
        else:
            site_location = add_ifc_cartesian_point(self.ifc_file, ZERO_LOCATION)
        axis = add_ifc_axis_2_placement_3D(self.ifc_file, site_location)
        local_placement = add_ifc_local_placement(self.ifc_file, axis)

        site = add_ifc_site(self.ifc_file, "Parcels", owner_history, local_placement)
        add_ifc_rel_aggregates(self.ifc_file, project, [site])

        styles = {}
        for key, value in self.color_definitions.items():
            color = add_ifc_colour_rgb(self.ifc_file, value[0:3])
            shading = add_ifc_surface_style_shading(self.ifc_file, color, value[3])
            styles[key] = add_ifc_surface_style(self.ifc_file, shading)

        logger.info("build geographic elements")
        if self.geometry_representation == GeometryRepresentaion.TESSELLATION:
            geographic_elements = self._build_geographic_elements_tessellation(
                representation_context, styles
            )
        elif self.geometry_representation == GeometryRepresentaion.BREP:
            geographic_elements = self._build_geographic_elements_brep(
                representation_context, styles
            )
        else:
            raise Exception()

        add_ifc_rel_aggregates(self.ifc_file, site, geographic_elements)
        logger.info("completed build ifc")

    def _build_geographic_elements_tessellation(
        self,
        representation_context: entity_instance,
        styles: dict[ColorDefionition, entity_instance],
    ) -> list[entity_instance]:
        if self.ifc_file is None:
            raise Exception("ifc file is not initialized")

        geographic_elements = []
        vertices_dict = {}
        vertices = []
        point_index_lists = []
        for index, triangulation in enumerate(self.parcels):
            logger.info(f"add triangulation {index + 1}/{len(self.parcels)}")
            for triangle in triangulation.triangles:
                for vertex in triangle:
                    if vertex not in vertices_dict:
                        shifted_vertex = (
                            vertex[0] - self.origin_shift[0],
                            vertex[1] - self.origin_shift[1],
                            vertex[2] - self.origin_shift[2],
                        )
                        vertices_dict[vertex] = len(vertices) + 1
                        vertices.append(shifted_vertex)
            point_index_lists.append(
                [
                    tuple(vertices_dict[v] for v in triangle)
                    for triangle in triangulation.triangles
                ]
            )
        cartesian_point_list = add_ifc_cartesian_point_list_3D(self.ifc_file, vertices)

        for point_index_list in point_index_lists:
            face_set = add_ifc_triangulated_face_set(
                self.ifc_file, cartesian_point_list, point_index_list
            )
            add_ifc_styled_item(
                self.ifc_file, face_set, styles[ColorDefionition.PARCEL]
            )
            shape_representation = add_ifc_shape_representation(
                self.ifc_file,
                representation_context,
                self.geometry_representation.value,
                face_set,
            )
            product_definition_shape = add_ifc_product_definition_shape(
                self.ifc_file, shape_representation
            )
            geographic_element = add_ifc_geographic_element(self.ifc_file)
            geographic_element.Representation = product_definition_shape
            geographic_elements.append(geographic_element)
        return geographic_elements

    def _build_geographic_elements_brep(
        self,
        representation_context: entity_instance,
        styles: dict[ColorDefionition, entity_instance],
    ) -> list[entity_instance]:
        if self.ifc_file is None:
            raise Exception("ifc file is not initialized")

        geographic_elements = []
        vertex_dict = {}
        for index, triangulation in enumerate(self.parcels):
            logger.info(f"add triangulation {index + 1}/{len(self.parcels)}")
            faces = []
            for triangle in triangulation.triangles:
                vertices = []
                for vertex in triangle:
                    if vertex not in vertex_dict:
                        shifted_vertex = (
                            vertex[0] - self.origin_shift[0],
                            vertex[1] - self.origin_shift[1],
                            vertex[2] - self.origin_shift[2],
                        )
                        vertex_dict[vertex] = add_ifc_cartesian_point(
                            self.ifc_file, shifted_vertex
                        )
                    vertices.append(vertex_dict[vertex])

                poly_loop = add_ifc_poly_loop(self.ifc_file, vertices)
                outer_bound = add_ifc_face_outer_bound(self.ifc_file, poly_loop)

                face = add_ifc_face(self.ifc_file, outer_bound)
                faces.append(face)

            closed_shell = add_ifc_closed_shell(self.ifc_file, faces)
            faceted_brep = add_ifc_faceted_brep(self.ifc_file, closed_shell)

            add_ifc_styled_item(
                self.ifc_file, faceted_brep, styles[ColorDefionition.PARCEL]
            )
            shape_representation = add_ifc_shape_representation(
                self.ifc_file,
                representation_context,
                self.geometry_representation.value,
                faceted_brep,
            )
            product_definition_shape = add_ifc_product_definition_shape(
                self.ifc_file, shape_representation
            )
            geographic_element = add_ifc_geographic_element(self.ifc_file)
            geographic_element.Representation = product_definition_shape
            geographic_elements.append(geographic_element)
        return geographic_elements

    def write(self, file_name: str):
        logger.info(f"write ifc to {file_name}")
        if not self.ifc_file is None:
            self.ifc_file.write(file_name)
        else:
            raise Exception()
