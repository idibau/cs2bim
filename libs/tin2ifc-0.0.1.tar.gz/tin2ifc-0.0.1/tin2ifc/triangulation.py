import logging
from stl import mesh

logger = logging.getLogger(__name__)


class Triangulation:
    def __init__(self) -> None:
        self.triangles: list[
            tuple[
                tuple[float, float, float],
                tuple[float, float, float],
                tuple[float, float, float],
            ]
        ] = []

    def load_from_stl(self, file_name: str) -> None:
        logger.info(f"read triangulation from file '{file_name}'")
        self.mesh = mesh.Mesh.from_file(file_name)
        v0 = list(map(Triangulation._create_tuple, self.mesh.v0))
        v1 = list(map(Triangulation._create_tuple, self.mesh.v1))
        v2 = list(map(Triangulation._create_tuple, self.mesh.v2))
        self.triangles = list(zip(v0, v1, v2))
        logger.info("completed read triangulation")

    @classmethod
    def _create_tuple(cls, l: list) -> tuple[float, float, float]:
        return (float(l[0]), float(l[1]), float(l[2]))
