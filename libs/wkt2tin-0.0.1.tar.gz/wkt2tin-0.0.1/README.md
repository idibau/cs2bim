# cs2bim-wkt2tin

## Build

```
python setup.py sdist
```