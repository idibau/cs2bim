# cs2bim-wkt2tin

## Build
```
pip install -q build
python -m build
```

The build files are saved in the "dist/" folder.

## Usage

See "examples/wkt2tin_example.ipynb"