from setuptools import find_packages, setup

setup(
    name="wkt2tin",
    packages=find_packages(include=["wkt2tin", "wkt2tin.*"]),
    version="0.0.1",
    description="wkt2tin",
    author="FHNW",
    install_requires=[
        "pyvista==0.43.8",
        "numpy==1.26.4",
        "shapely==2.0.4",
        "geopandas==0.14.4",
        "pandas==2.2.2",
    ],
    tests_require=["pytest==4.4.1"],
    test_suite="test",
)
