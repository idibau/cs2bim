import numpy as np
import shapely
import pyvista as pv
import shapely.geometry


class Area(object):
    """
    Class representing a polygonal area including holes if present.

    NOTE
    ----
    Circular arcs are not supported. Therefore the must be segmented in advance.

    ``ST_CurveToLine`` https://postgis.net/docs/ST_CurveToLine.html provides such
    functionality. However, make sure to use ``flag 1`` to create symmetric output.
    Otherwise the adjacent areas might overlap.

    Parameters
    ----------
    wkt_str : str
        WKT string defining the polygon
    origin : np.ndarray of form [x, y]
        Origin to reduce coordinate values
    """

    def __init__(self, wkt_str: str, origin: np.ndarray = np.zeros((2,))) -> None:
        assert isinstance(wkt_str, str)
        self._geometry = shapely.from_wkt(wkt_str)

        if not shapely.is_ccw(self._geometry):
            self._reverse()

        assert origin.shape == (2,)
        if not np.allclose(origin, np.zeros((2,))):
            self._reduce(origin)

    def _reverse(self):
        """Reverses order of vertices of exterior and interior boundaries"""
        shell = np.stack(self._geometry.exterior.coords.xy).T[::-1].tolist()
        holes = [np.stack(hole.coords.xy).T[::-1].tolist() for hole in self._geometry.interiors]

        self._geometry = shapely.geometry.Polygon(shell=shell, holes=holes)

    def _reduce(self, origin):
        """Reduce coordinates by origin"""

        shell = (np.stack(self._geometry.exterior.coords.xy).T - origin).tolist()

        holes = []
        for hole in [np.stack(geom.coords.xy).T for geom in self._geometry.interiors]:
            holes.append((hole - origin).tolist())

        self._geometry = shapely.geometry.Polygon(shell=shell, holes=holes)

    @property
    def get_geometry(self) -> shapely.geometry.Polygon:
        return self._geometry

    def get_exterior_points(self, exclude_last_point: bool = True) -> np.ndarray:
        """
        Returns vertices of exterior boundary

        Parameters
        ----------
        exclude_last_point : bool; default = True
            Whether to exclude last point (which is identical with first point)

        Returns
        -------
        _ : np.ndarray
        """
        points = np.stack(self._geometry.exterior.coords.xy).T
        if exclude_last_point:
            points = points[:-1]

        return points

    @property
    def n_interiors(self) -> int:
        """Returns number boundaries (holes)"""
        return len(self._geometry.interiors)

    def get_interior_points(self, exclude_last_point: bool = True) -> list[np.ndarray]:
        """
        Returns vertices of all interior boundaries

        Parameters
        ----------
        exclude_last_point : bool; default = True
            Whether to exclude last point (which is identical with first point)

        Returns
        -------
        _ : list[np.ndarray]
        """
        points = [np.stack(geom.coords.xy).T for geom in self._geometry.interiors]

        if exclude_last_point:
            points = [p[:-1] for p in points]

        return points

    @property
    def get_area(self) -> float:
        """Returns area"""
        return self._geometry.area


class Boundary(object):
    """
    Class representing a boundary object.
    It can create a volume to clip a mesh with.

    Parameters
    ----------
    points : np.ndarray
        Vertices of boundary in counterclockwise (ccw) order.
    z_min : float
        Min height to extrude boundary
    z_max : float
        Max height to extrude boundary
    """

    def __init__(self, points: np.ndarray, z_min: float, z_max: float) -> None:
        self.point = None
        self.n_points = None
        self.z_min = z_min
        self.z_max = z_max
        self._add_points(points)

    def _add_points(self, points):
        """Add points"""
        assert isinstance(points, np.ndarray)
        assert points.ndim == 2
        assert points.shape[1] == 2

        self.points = points
        self.n_points = int(points.shape[0])

    def extrude(self) -> pv.core.pointset.PolyData:
        """
        Creates a volume (extruded boundary) to clip mesh with

        Returns
        -------
        _ : v.core.pointset.PolyData
            Volume to clip mesh with
        """

        poly = pv.PolyData(
            [
                p.tolist()
                + [
                    self.z_min,
                ]
                for p in self.points
            ],
            faces=[self.n_points, *range(self.n_points)],
        )
        poly = poly.delaunay_2d(edge_source=poly)

        return poly.extrude((0, 0, self.z_max - self.z_min), capping=True)
